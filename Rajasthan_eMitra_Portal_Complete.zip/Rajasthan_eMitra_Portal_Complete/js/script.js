document.addEventListener("DOMContentLoaded", function() {
    console.log("ई-मित्र पोर्टल लोड हो गया है।");
});
